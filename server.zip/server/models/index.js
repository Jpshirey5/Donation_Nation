const Tech = require('./Tech');
const Matchup = require('./Matchup');

module.exports = { Tech, Matchup };
