const User = require('./User');
const Charity = require('./Charity');

module.exports = { User, Charity };
